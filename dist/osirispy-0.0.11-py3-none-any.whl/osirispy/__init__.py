from . import osirispy
from .osirispy import *